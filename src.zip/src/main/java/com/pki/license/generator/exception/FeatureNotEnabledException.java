package com.pki.license.generator.exception;

public class FeatureNotEnabledException extends RuntimeException {

	public FeatureNotEnabledException(String exceptionCode, String message) {
		super(message);
		this.exceptionCode = exceptionCode;

	}

	private static final long serialVersionUID = 1L;
	private final String exceptionCode;

	public String getExceptionCode() {
		return exceptionCode;
	}
}
