package com.pki.license.generator.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pki.license.generator.domain.Customer;
import com.pki.license.generator.dto.CustomerDTO;
import com.pki.license.generator.exception.ApplicationValidationException;
import com.pki.license.generator.exception.ResourceNotFoundException;
import com.pki.license.generator.repository.CustomerRepository;
import com.pki.license.generator.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	private static final String UNABLE_TO_FIND_THE_CUSTOMER_DATA_FOR_THE_GIVEN_ID = "Unable to find the customer data for the given  id";
	private static final String E100001 = "E100001";
	private static final String CUSTOMER_DATA_ALREADY_EXISTS = "Customer with the same email id already exists";
	private static final String E100002 = "E100002";
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public CustomerDTO getCustomer(UUID customerId) {
		CustomerDTO customerDTO = null;
		Optional<Customer> customerWrapper = customerRepository.findById(customerId);
		if (customerWrapper != null && customerWrapper.isPresent()) {
			Customer customer = customerWrapper.get();
			customerDTO = modelMapper.map(customer, CustomerDTO.class);
		} else {
			throw new ResourceNotFoundException(E100001, UNABLE_TO_FIND_THE_CUSTOMER_DATA_FOR_THE_GIVEN_ID);
		}
		return customerDTO;
	}

	@Override
	public List<CustomerDTO> getAllCustomers() {
		List<Customer> customerList = customerRepository.findAll();
		return customerList.stream().map(customer -> modelMapper.map(customer, CustomerDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public CustomerDTO addCustomer(CustomerDTO customerDTO) {
		List<Customer> customerList = customerRepository.findAllByEmailId(customerDTO.getEmailId());
		customerDTO.setCustomerId(UUID.randomUUID());
		if (customerList != null && !customerList.isEmpty()) {
			throw new ApplicationValidationException(E100002, CUSTOMER_DATA_ALREADY_EXISTS);
		}
		Customer customer = modelMapper.map(customerDTO, Customer.class);
		customer = customerRepository.save(customer);

		return customerDTO;
	}

	@Override
	public CustomerDTO updateCustomer(CustomerDTO customerDTO, UUID customerId) {
		Optional<Customer> customerWrapper = customerRepository.findById(customerId);
		if (customerWrapper != null && customerWrapper.isPresent()) {
			Customer customer = customerWrapper.get();
			modelMapper.map(customerDTO, customer);
			customerRepository.save(customer);
		} else {
			throw new ResourceNotFoundException(E100001, UNABLE_TO_FIND_THE_CUSTOMER_DATA_FOR_THE_GIVEN_ID);
		}
		return customerDTO;
	}

	@Override
	public CustomerDTO deleteCustomer(UUID customerId) {
		Optional<Customer> customerWrapper = customerRepository.findById(customerId);
		if (customerWrapper != null && customerWrapper.isPresent()) {
			Customer customer = customerWrapper.get();
			customerRepository.delete(customer);
			return modelMapper.map(customer, CustomerDTO.class);
		} else {
			throw new ResourceNotFoundException(E100001, UNABLE_TO_FIND_THE_CUSTOMER_DATA_FOR_THE_GIVEN_ID);
		}
	}
}
