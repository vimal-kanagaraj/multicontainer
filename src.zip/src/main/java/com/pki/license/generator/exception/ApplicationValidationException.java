package com.pki.license.generator.exception;

public class ApplicationValidationException extends RuntimeException {
	public ApplicationValidationException(String exceptionCode, String message) {
		super(message);
		this.exceptionCode = exceptionCode;
	}

	private static final long serialVersionUID = 1L;
	private final String exceptionCode;

	public String getExceptionCode() {
		return exceptionCode;
	}
}
