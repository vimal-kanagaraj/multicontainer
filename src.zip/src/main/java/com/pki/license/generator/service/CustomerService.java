package com.pki.license.generator.service;

import java.util.List;
import java.util.UUID;

import com.pki.license.generator.dto.CustomerDTO;

public interface CustomerService {

	List<CustomerDTO> getAllCustomers();

	CustomerDTO addCustomer(CustomerDTO customerDTO);

	CustomerDTO updateCustomer(CustomerDTO customerDTO, UUID customerId);

	CustomerDTO deleteCustomer(UUID customerId);

	CustomerDTO getCustomer(UUID customerId);

}
