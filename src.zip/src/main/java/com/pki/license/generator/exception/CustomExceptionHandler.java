package com.pki.license.generator.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@Order(Ordered.LOWEST_PRECEDENCE)
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String ERROR_RESPONSE_SENT = "Error response sent   : {}: {}";

	private static Logger loggerCustomerApp = LoggerFactory.getLogger(CustomExceptionHandler.class);

	@Autowired
	private MessageSource messageSource;

	@ExceptionHandler(ResourceNotFoundException.class)
	@Order(1)
	public static final ResponseEntity<ErrorResponse> handleResourceNotFoundException(
			ResourceNotFoundException exception, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setCode(exception.getExceptionCode());
		errorResponse.setMessage(exception.getMessage());
		loggerCustomerApp.error(ERROR_RESPONSE_SENT, errorResponse.getCode(), errorResponse.getMessage(), exception);
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(FeatureNotEnabledException.class)
	@Order(2)
	public static final ResponseEntity<ErrorResponse> handleFeatureNotEnabledException(
			FeatureNotEnabledException exception, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setCode("E50001");
		errorResponse.setMessage("The requested feature is not available as of now");
		loggerCustomerApp.error(ERROR_RESPONSE_SENT, errorResponse.getCode(), errorResponse.getMessage(), exception);
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(Exception.class)
	@Order(3)
	public static final ResponseEntity<ErrorResponse> handleGenericException(Exception exception, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setCode("E40001");
		errorResponse.setMessage("Internal server error");
		loggerCustomerApp.error(ERROR_RESPONSE_SENT, errorResponse.getCode(), errorResponse.getMessage(), exception);
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		String validationMessage = ex.getBindingResult().getAllErrors().get(0).getDefaultMessage();
		ErrorResponse errorResponse = buildErrorResponse(validationMessage, validationMessage);
		loggerCustomerApp.error("Validation Error response sent   : \"E30001\": {}", errorResponse.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	private ErrorResponse buildErrorResponse(String validationMessage, String defaultMessage) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setCode(validationMessage);
		errorResponse.setMessage(
				messageSource.getMessage(validationMessage, null, defaultMessage, LocaleContextHolder.getLocale()));
		return errorResponse;
	}
}
