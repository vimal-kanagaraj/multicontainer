package com.pki.license.generator.dto;

import java.util.List;
import java.util.UUID;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Customer model contains the customer details")
public class CustomerDTO {

	@ApiModelProperty(notes = "Customer Unique Identification Number ")
	private UUID customerId;

	@Email(message = "invalid.email.id")
	@ApiModelProperty(notes = "EmailID should have valid email id ")
	@NotEmpty
	private String emailId;

	@ApiModelProperty(notes = "Name should have at least 2 characters and should not exceed more than 50 characters ")
	@Size(max = 50, min = 2, message = "invalid.name")
	@NotEmpty(message = "invalid.name")
	private String name;

	@NotEmpty(message = "invalid.contactNumber")
	@ApiModelProperty(notes = "Contact Number should not be blank ")
	private String contactNumber;

	@NotEmpty(message = "invalid.address")
	@ApiModelProperty(notes = "Address  should not be blank ")
	private String address;

	@NotEmpty(message = "invalid.state")
	@ApiModelProperty(notes = "State  should not be blank ")
	private String state;

	@NotEmpty(message = "invalid.country")
	@ApiModelProperty(notes = "Country  should not be blank ")
	private String country;

	@NotEmpty(message = "invalid.zipcode")
	@ApiModelProperty(notes = "Zipcode  should not be blank ")
	private String zipcode;

	private String notes;

	private List<LicenseDTO> licenses;

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the contactNumber
	 */
	public String getContactNumber() {
		return contactNumber;
	}

	/**
	 * @param contactNumber the contactNumber to set
	 */
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the zipcode
	 */
	public String getZipcode() {
		return zipcode;
	}

	/**
	 * @param zipcode the zipcode to set
	 */
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}

	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * @return the customerId
	 */
	public UUID getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(UUID customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the licenses
	 */
	public List<LicenseDTO> getLicenses() {
		return licenses;
	}

	/**
	 * @param licenses the licenses to set
	 */
	public void setLicenses(List<LicenseDTO> licenses) {
		this.licenses = licenses;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
