package com.pki.license.generator.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pki.license.generator.domain.Feature;
import com.pki.license.generator.domain.Product;
import com.pki.license.generator.dto.FeatureDTO;
import com.pki.license.generator.dto.ProductDTO;
import com.pki.license.generator.exception.ApplicationValidationException;
import com.pki.license.generator.exception.ResourceNotFoundException;
import com.pki.license.generator.repository.FeatureRepository;
import com.pki.license.generator.repository.ProductRepository;
import com.pki.license.generator.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	private static final String UNABLE_TO_FIND_THE_PRODUCT_DATA_FOR_THE_GIVEN_ID = "Unable to find the product data for the given  id";
	private static final String E100003 = "E100003";
	private static final String PRODUCT_DATA_ALREADY_EXISTS = "Product with the same name  already exists";
	private static final String E100004 = "E100004";
	@Autowired
	ProductRepository productRepository;
	@Autowired
	FeatureRepository featureRepository;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public ProductDTO getProduct(UUID productId) {
		ProductDTO productDTO = null;
		Optional<Product> productWrapper = productRepository.findById(productId);
		if (productWrapper != null && productWrapper.isPresent()) {
			Product product = productWrapper.get();
			productDTO = modelMapper.map(product, ProductDTO.class);
		} else {
			throw new ResourceNotFoundException(E100003, UNABLE_TO_FIND_THE_PRODUCT_DATA_FOR_THE_GIVEN_ID);
		}
		return productDTO;
	}

	@Override
	public List<ProductDTO> getAllProducts() {
		List<Product> productList = productRepository.findAll();
		return productList.stream().map(product -> modelMapper.map(product, ProductDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public ProductDTO addProduct(ProductDTO productDTO) {
		List<Product> productList = productRepository.findAllByName(productDTO.getName());
		productDTO.setProductId(UUID.randomUUID());
		if (productList != null && !productList.isEmpty()) {
			throw new ApplicationValidationException(E100004, PRODUCT_DATA_ALREADY_EXISTS);
		}
		Product product = modelMapper.map(productDTO, Product.class);
		product = productRepository.save(product);

		return productDTO;
	}

	@Override
	public ProductDTO updateProduct(ProductDTO productDTO, UUID productId) {
		Optional<Product> productWrapper = productRepository.findById(productId);
		if (productWrapper != null && productWrapper.isPresent()) {
			Product product = productWrapper.get();
			modelMapper.map(productDTO, product);
			productRepository.save(product);
		} else {
			throw new ResourceNotFoundException(E100003, UNABLE_TO_FIND_THE_PRODUCT_DATA_FOR_THE_GIVEN_ID);
		}
		return productDTO;
	}

	@Override
	public ProductDTO deleteProduct(UUID productId) {
		Optional<Product> productWrapper = productRepository.findById(productId);
		if (productWrapper != null && productWrapper.isPresent()) {
			Product product = productWrapper.get();
			productRepository.delete(product);
			return modelMapper.map(product, ProductDTO.class);
		} else {
			throw new ResourceNotFoundException(E100003, UNABLE_TO_FIND_THE_PRODUCT_DATA_FOR_THE_GIVEN_ID);
		}
	}

	@Override
	public List<FeatureDTO> getAllFeatures(UUID productId) {
		/*
		 * List<Feature> featureList =
		 * featureRepository.findAllByProductByProductId(productId); return
		 * featureList.stream().map(feature -> modelMapper.map(feature,
		 * FeatureDTO.class)) .collect(Collectors.toList());
		 */
		return null;
	}

	@Override
	public FeatureDTO getFeature(UUID productId, UUID featureId) {
		FeatureDTO featureDTO = null;
		Optional<Feature> featureWrapperOptional = featureRepository.findById(featureId);
		if (featureWrapperOptional != null && featureWrapperOptional.isPresent()) {
			Feature feature = featureWrapperOptional.get();
			featureDTO = modelMapper.map(feature, FeatureDTO.class);
		} else {
			throw new ResourceNotFoundException(E100003, UNABLE_TO_FIND_THE_PRODUCT_DATA_FOR_THE_GIVEN_ID);
		}
		return featureDTO;
	}

	@Override
	public FeatureDTO addFeature(@Valid FeatureDTO feature, UUID productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FeatureDTO updateFeature(FeatureDTO feature, UUID productId, UUID featureId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FeatureDTO deleteFeature(UUID productId, UUID featureId) {
		// TODO Auto-generated method stub
		return null;
	}
}
