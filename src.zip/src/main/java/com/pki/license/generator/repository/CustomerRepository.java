package com.pki.license.generator.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pki.license.generator.domain.Customer;

@Repository
@Transactional
public interface CustomerRepository extends JpaRepository<Customer, UUID> {
	List<Customer> findAllByEmailId(String emailId);
}