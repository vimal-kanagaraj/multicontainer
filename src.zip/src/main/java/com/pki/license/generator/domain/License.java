package com.pki.license.generator.domain;

import java.util.Date;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "LICENSE")
public class License {
	@Id
	@Column(name = "LICENSE_ID")
	private UUID licenseId;
	@Column(name = "DESCRIPTION")
	private String description;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "LICENSE_FEATURE", joinColumns = @JoinColumn(name = "LICENSE_ID"), inverseJoinColumns = @JoinColumn(name = "FEATURE_ID"))
	private Set<Feature> mappedFeatures;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "product_id")
	private Product product;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "customer_id")
	private Customer customer;

	@Column(name = "VALID_FROM")
	private Date validFrom;
	@Column(name = "VALID_TILL")
	private Date validTill;
	@Column(name = "PUBLIC_KEY")
	private String publicKey;
	@Column(name = "LICENSE_STRING")
	private String licenseString;
	@Column(name = "HARDWARE_UNIQUE_NUMBERS")
	private String hardwareUniqueNumbers;

	/**
	 * @return the features
	 */
	public Set<Feature> getFeatures() {
		return mappedFeatures;
	}

	/**
	 * @param features the features to set
	 */
	public void setFeatures(Set<Feature> mappedFeatures) {
		this.mappedFeatures = mappedFeatures;
	}

	/**
	 * @return the customer
	 */
	public Customer getCustomer() {
		return customer;
	}

	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/**
	 * @return the licenseId
	 */
	public UUID getLicenseId() {
		return licenseId;
	}

	/**
	 * @param licenseId the licenseId to set
	 */
	public void setLicenseId(UUID licenseId) {
		this.licenseId = licenseId;
	}

	/**
	 * @return the validFrom
	 */
	public Date getValidFrom() {
		return validFrom;
	}

	/**
	 * @param validFrom the validFrom to set
	 */
	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	/**
	 * @return the validTill
	 */
	public Date getValidTill() {
		return validTill;
	}

	/**
	 * @param validTill the validTill to set
	 */
	public void setValidTill(Date validTill) {
		this.validTill = validTill;
	}

	/**
	 * @return the publicKey
	 */
	public String getPublicKey() {
		return publicKey;
	}

	/**
	 * @param publicKey the publicKey to set
	 */
	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	/**
	 * @return the licenseString
	 */
	public String getLicenseString() {
		return licenseString;
	}

	/**
	 * @param licenseString the licenseString to set
	 */
	public void setLicenseString(String licenseString) {
		this.licenseString = licenseString;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * @return the hardwareUniqueNumbers
	 */
	public String getHardwareUniqueNumbers() {
		return hardwareUniqueNumbers;
	}

	/**
	 * @param hardwareUniqueNumbers the hardwareUniqueNumbers to set
	 */
	public void setHardwareUniqueNumbers(String hardwareUniqueNumbers) {
		this.hardwareUniqueNumbers = hardwareUniqueNumbers;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
