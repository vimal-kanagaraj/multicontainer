package com.pki.license.generator.dto;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "License model contains the feature details")
public class LicenseDTO {

	@ApiModelProperty(notes = "License Unique Identification Number ")
	private UUID licenseId;

	private String description;

	private List<FeatureDTO> features;

	private ProductDTO product;

	private CustomerDTO customer;

	private Date validFrom;
	private Date validTill;
	private String publicKey;
	private String licenseString;
	private List<String> hardwareUniqueNumbers;

	/**
	 * @return the features
	 */
	public List<FeatureDTO> getFeatures() {
		return features;
	}

	/**
	 * @param features the features to set
	 */
	public void setFeatures(List<FeatureDTO> features) {
		this.features = features;
	}

	/**
	 * @return the customer
	 */
	public CustomerDTO getCustomer() {
		return customer;
	}

	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(CustomerDTO customer) {
		this.customer = customer;
	}

	/**
	 * @return the licenseId
	 */
	public UUID getLicenseId() {
		return licenseId;
	}

	/**
	 * @param licenseId the licenseId to set
	 */
	public void setLicenseId(UUID licenseId) {
		this.licenseId = licenseId;
	}

	/**
	 * @return the validFrom
	 */
	public Date getValidFrom() {
		return validFrom;
	}

	/**
	 * @param validFrom the validFrom to set
	 */
	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	/**
	 * @return the validTill
	 */
	public Date getValidTill() {
		return validTill;
	}

	/**
	 * @param validTill the validTill to set
	 */
	public void setValidTill(Date validTill) {
		this.validTill = validTill;
	}

	/**
	 * @return the publicKey
	 */
	public String getPublicKey() {
		return publicKey;
	}

	/**
	 * @param publicKey the publicKey to set
	 */
	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	/**
	 * @return the licenseString
	 */
	public String getLicenseString() {
		return licenseString;
	}

	/**
	 * @param licenseString the licenseString to set
	 */
	public void setLicenseString(String licenseString) {
		this.licenseString = licenseString;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the product
	 */
	public ProductDTO getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(ProductDTO product) {
		this.product = product;
	}

	/**
	 * @return the hardwareUniqueNumbers
	 */
	public List<String> getHardwareUniqueNumbers() {
		return hardwareUniqueNumbers;
	}

	/**
	 * @param hardwareUniqueNumbers the hardwareUniqueNumbers to set
	 */
	public void setHardwareUniqueNumbers(List<String> hardwareUniqueNumbers) {
		this.hardwareUniqueNumbers = hardwareUniqueNumbers;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
