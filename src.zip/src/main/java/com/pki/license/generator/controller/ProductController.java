package com.pki.license.generator.controller;

import java.net.URI;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.pki.license.generator.dto.FeatureDTO;
import com.pki.license.generator.dto.ProductDTO;
import com.pki.license.generator.service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(tags = " Product Service to manage product information")
@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService productService;

	@GetMapping(path = "/")
	@ApiOperation(value = "Get products", response = ProductDTO.class, notes = "Get product details ")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fetched the all product details successfully"),
			@ApiResponse(code = 404, message = "Unable to find the product data "),
			@ApiResponse(code = 500, message = "Internal Server Error") })

	public List<ProductDTO> getAllProducts() {
		return productService.getAllProducts();
	}

	@GetMapping(path = "/{productId}")
	@ApiOperation(value = "Get product", response = ProductDTO.class, notes = "Get product details for the given product id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fetched the product details successfully"),
			@ApiResponse(code = 404, message = "Unable to find the product data for the given id"),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	public ProductDTO getProduct(@PathVariable UUID productId) {
		return productService.getProduct(productId);
	}

	@PostMapping(path = "/")
	public ResponseEntity<Object> addProduct(@Valid @RequestBody ProductDTO product) {
		ProductDTO productDTO = productService.addProduct(product);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{productId}")
				.buildAndExpand(productDTO.getProductId()).toUri();
		return ResponseEntity.created(location).build();
	}

	@PutMapping(path = "/{productId}")
	public ProductDTO updateProduct(@RequestBody ProductDTO product, @PathVariable UUID productId) {
		return productService.updateProduct(product, productId);
	}

	@DeleteMapping(path = "/{productId}")
	public ProductDTO deleteProduct(@PathVariable UUID productId) {
		return productService.deleteProduct(productId);
	}

	@GetMapping(path = "/{productId}/features")
	@ApiOperation(value = "Get product features", response = FeatureDTO.class, notes = "Get product feature details ")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fetched the  product feature details successfully"),
			@ApiResponse(code = 404, message = "Unable to find the features data "),
			@ApiResponse(code = 500, message = "Internal Server Error") })

	public List<FeatureDTO> getAllFeatures(@PathVariable UUID productId) {
		return productService.getAllFeatures(productId);
	}

	@GetMapping(path = "/{productId}/features/{featureId}")
	@ApiOperation(value = "Get product feature ", response = FeatureDTO.class, notes = "Get product feature details for the given feature id")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Fetched the feature details successfully"),
			@ApiResponse(code = 404, message = "Unable to find the feature data for the given id"),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	public FeatureDTO getFeature(@PathVariable UUID productId, @PathVariable UUID featureId) {
		return productService.getFeature(productId, featureId);
	}

	@PostMapping(path = "/{productId}/features/")
	public ResponseEntity<Object> addFeature(@PathVariable UUID productId, @Valid @RequestBody FeatureDTO feature) {
		FeatureDTO featureDTO = productService.addFeature(feature, productId);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{featureId}")
				.buildAndExpand(featureDTO.getFeatureId()).toUri();
		return ResponseEntity.created(location).build();
	}

	@PutMapping(path = "/{productId}/features/{featureId}")
	public FeatureDTO updateFeature(@RequestBody FeatureDTO feature, @PathVariable UUID productId,
			@PathVariable UUID featureId) {
		return productService.updateFeature(feature, productId, featureId);
	}

	@DeleteMapping(path = "/{productId}/features/{featureId}")
	public FeatureDTO deleteProduct(@PathVariable UUID productId, @PathVariable UUID featureId) {
		return productService.deleteFeature(productId, featureId);
	}
}
