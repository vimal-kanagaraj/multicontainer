package com.pki.license.generator.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pki.license.generator.domain.Feature;

@Repository
@Transactional
public interface FeatureRepository extends JpaRepository<Feature, UUID> {

	// List<Feature> findAllByProductByProductId(UUID productId);
}