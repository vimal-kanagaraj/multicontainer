package com.pki.license.generator.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pki.license.generator.domain.Product;

@Repository
@Transactional
public interface ProductRepository extends JpaRepository<Product, UUID> {

	List<Product> findAllByName(String name);
}