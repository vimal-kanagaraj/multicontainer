package com.pki.license.generator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LicenseGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(LicenseGeneratorApplication.class, args);
	}

}
