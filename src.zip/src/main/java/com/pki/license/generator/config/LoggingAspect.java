package com.pki.license.generator.config;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

@Aspect
@Configuration
public class LoggingAspect {

	private static Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

	@Around("execution(* com.pki.license.generator.*.*(..)) || execution(* com.pki.license.generator.*.*(..))")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
		MethodSignature signature = (MethodSignature) joinPoint.getSignature();

		logger.info("Entered into : {} : {} : {} ", signature.getDeclaringTypeName(), signature.getName(),
				joinPoint.getArgs());
		Object result = joinPoint.proceed();
		logger.info("Exited from  : {} : {} ", signature.getDeclaringTypeName(), signature.getName());
		if (result != null) {
			logger.debug("Method Return value from {} method is {} ", getMethodName(signature), result);
		}
		return result;
	}

	private String getMethodName(MethodSignature signature) {
		return signature.getDeclaringTypeName().concat(" : ").concat(signature.getName());
	}

}
