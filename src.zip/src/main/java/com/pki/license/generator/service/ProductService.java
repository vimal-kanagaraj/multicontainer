package com.pki.license.generator.service;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;

import com.pki.license.generator.dto.FeatureDTO;
import com.pki.license.generator.dto.ProductDTO;

public interface ProductService {

	List<ProductDTO> getAllProducts();

	ProductDTO addProduct(ProductDTO productDTO);

	ProductDTO updateProduct(ProductDTO productDTO, UUID productId);

	ProductDTO deleteProduct(UUID productId);

	List<FeatureDTO> getAllFeatures(UUID productId);

	ProductDTO getProduct(UUID productId);

	FeatureDTO getFeature(UUID productId, UUID featureId);

	FeatureDTO addFeature(@Valid FeatureDTO feature, UUID productId);

	FeatureDTO updateFeature(FeatureDTO feature, UUID productId, UUID featureId);

	FeatureDTO deleteFeature(UUID productId, UUID featureId);

}
